import { Link, useNavigate } from "@tanstack/react-router";
import { Search, ShoppingBag, User as UserIcon, LogOut } from "lucide-react";
import logo from "@/assets/skinaura-logo.png.asset.json";
import { useCart } from "@/lib/cart-context";
import { useAuth } from "@/lib/auth-context";

export function Header() {
  const { count } = useCart();
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-40 glass-pink">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
        <Link to="/" className="flex items-center gap-2 press">
          <img src={logo.url} alt="Skinaura" width={36} height={36} className="h-9 w-9 object-contain" />
          <span className="bold-tight text-xl tracking-tight">Skin<span className="text-gradient-pink">aura</span></span>
        </Link>
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-foreground/80">
          <Link to="/" className="hover:text-primary">Home</Link>
          <Link to="/category/$slug" params={{ slug: "skincare" }} className="hover:text-primary">Skincare</Link>
          <Link to="/category/$slug" params={{ slug: "makeup" }} className="hover:text-primary">Makeup</Link>
          <Link to="/category/$slug" params={{ slug: "haircare" }} className="hover:text-primary">Haircare</Link>
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/search" aria-label="Search" className="grid h-10 w-10 place-items-center rounded-full glass press">
            <Search size={18} />
          </Link>
          <Link to="/cart" aria-label="Cart" className="relative grid h-10 w-10 place-items-center rounded-full glass press">
            <ShoppingBag size={18} />
            {count > 0 && (
              <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[11px] font-bold text-primary-foreground">
                {count}
              </span>
            )}
          </Link>
          {user ? (
            <button
              onClick={async () => { await signOut(); navigate({ to: "/" }); }}
              aria-label="Sign out"
              className="grid h-10 w-10 place-items-center rounded-full glass press"
              title={user.email ?? "Sign out"}
            >
              <LogOut size={18} />
            </button>
          ) : (
            <Link to="/auth" aria-label="Sign in" className="grid h-10 w-10 place-items-center rounded-full glass press">
              <UserIcon size={18} />
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
