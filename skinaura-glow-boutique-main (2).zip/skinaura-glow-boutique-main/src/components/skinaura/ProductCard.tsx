import { Link } from "@tanstack/react-router";
import { priceOf, imgOf, type FlatProduct } from "@/lib/skinaura-utils";
import { isProductOOS } from "@/data/skinaura";

export function ProductCard({ p }: { p: FlatProduct }) {
  const { base, now, disc, sizeLabel } = priceOf(p);
  const oos = isProductOOS(p.brand, p);
  return (
    <Link
      to="/product/$slug"
      params={{ slug: p.slug }}
      className="group block overflow-hidden rounded-2xl glass card-hover"
    >
      <div className="relative aspect-square overflow-hidden bg-white/60">
        <img
          src={imgOf(p)}
          alt={p.name}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {!oos && disc > 0 && (
          <span className="absolute left-2 top-2 rounded-full bg-primary px-2 py-1 text-[10px] font-bold text-primary-foreground">
            {disc}% OFF
          </span>
        )}
        {oos && (
          <span className="absolute right-2 top-2 rounded-full bg-foreground/80 px-2 py-1 text-[10px] font-bold text-background">
            Out of stock
          </span>
        )}
      </div>
      <div className="p-3">
        <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{p.brand}</div>
        <div className="line-clamp-2 text-sm font-semibold text-foreground">{p.name}</div>
        <div className="mt-1 flex items-baseline gap-2">
          <span className="text-base font-bold text-primary">₹{now}</span>
          {disc > 0 && <span className="text-xs text-muted-foreground line-through">₹{base}</span>}
          {sizeLabel && <span className="ml-auto text-[10px] text-muted-foreground">{sizeLabel}</span>}
        </div>
      </div>
    </Link>
  );
}
