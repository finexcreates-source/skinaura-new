import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { brandBySlug, productsByBrand } from "@/lib/skinaura-utils";
import { ProductCard } from "@/components/skinaura/ProductCard";

export const Route = createFileRoute("/brand/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `${decodeURIComponent(params.slug)} products — Skinaura` },
      { name: "description", content: `Shop all ${params.slug} products on Skinaura.` },
    ],
  }),
  component: BrandPage,
  notFoundComponent: () => <div className="p-10 text-center">Brand not found</div>,
});

function BrandPage() {
  const { slug } = Route.useParams();
  const brand = brandBySlug(slug);
  if (!brand) throw notFound();
  const products = productsByBrand(brand.name);
  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <Link to="/" className="inline-flex items-center gap-1 text-sm font-semibold text-primary press">
        <ArrowLeft size={16} /> Back
      </Link>
      <div className="mt-4 flex items-center gap-4 rounded-2xl glass p-4">
        <div className="grid h-16 w-16 place-items-center overflow-hidden rounded-xl bg-white">
          <img src={brand.logo} alt={brand.name} className="h-full w-full object-contain" />
        </div>
        <div>
          <h1 className="bold-tight text-2xl md:text-3xl">{brand.name} <span className="display text-gradient-pink">products</span></h1>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">{brand.tag} · {products.length} item{products.length === 1 ? "" : "s"}</p>
        </div>
      </div>
      {products.length === 0 ? (
        <p className="mt-10 text-center text-muted-foreground">No products yet for this brand.</p>
      ) : (
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {products.map((p) => (<ProductCard key={p.slug} p={p} />))}
        </div>
      )}
    </div>
  );
}
