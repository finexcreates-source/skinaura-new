import { createFileRoute, Link } from "@tanstack/react-router";
import { Search as SearchIcon, ArrowLeft } from "lucide-react";
import { useMemo, useState } from "react";
import { searchProducts, allProducts } from "@/lib/skinaura-utils";
import { ProductCard } from "@/components/skinaura/ProductCard";

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>) => ({ q: typeof s.q === "string" ? s.q : "" }),
  head: () => ({ meta: [{ title: "Search — Skinaura" }] }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const [query, setQuery] = useState(q || "");
  const results = useMemo(() => (query.trim() ? searchProducts(query) : allProducts.slice(0, 24)), [query]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <Link to="/" className="inline-flex items-center gap-1 text-sm font-semibold text-primary press">
        <ArrowLeft size={16} /> Back
      </Link>
      <h1 className="mt-3 bold-tight text-2xl md:text-3xl">Search <span className="display text-gradient-pink">Skinaura</span></h1>
      <div className="mt-4 flex items-center gap-2 rounded-full glass px-4 py-3">
        <SearchIcon size={18} className="text-muted-foreground" />
        <input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products, brands, categories…"
          className="w-full bg-transparent text-base outline-none placeholder:text-muted-foreground"
        />
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        {query.trim() ? `${results.length} result${results.length === 1 ? "" : "s"}` : "Type to search · showing popular picks"}
      </p>
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {results.map((p) => (<ProductCard key={p.slug} p={p} />))}
      </div>
    </div>
  );
}
