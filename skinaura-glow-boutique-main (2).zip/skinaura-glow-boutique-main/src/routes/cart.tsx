import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Minus, Plus, Trash2, MessageCircle, ShoppingBag } from "lucide-react";
import { useCart } from "@/lib/cart-context";
import { whatsappOrderLink } from "@/lib/skinaura-utils";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [{ title: "Your cart — Skinaura" }] }),
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove, clear, count, subtotalOld, subtotalNow, savings } = useCart();

  const orderText = items.length
    ? "Hi! I'd like to order:\n" +
      items.map((l) => `• ${l.brand} — ${l.name} (${l.sizeLabel}) × ${l.qty} = ₹${l.unitPrice * l.qty}`).join("\n") +
      `\n\nSubtotal: ₹${subtotalNow}  (Saved ₹${savings})`
    : "";

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <Link to="/" className="inline-flex items-center gap-1 text-sm font-semibold text-primary press">
        <ArrowLeft size={16} /> Continue shopping
      </Link>
      <h1 className="mt-3 bold-tight text-2xl md:text-3xl">Your <span className="display text-gradient-pink">cart</span></h1>

      {count === 0 ? (
        <div className="mt-12 rounded-3xl glass p-10 text-center">
          <ShoppingBag size={48} className="mx-auto text-muted-foreground" />
          <p className="mt-4 text-muted-foreground">Your cart is empty.</p>
          <Link to="/search" className="mt-4 inline-block rounded-full bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground press">Start shopping</Link>
        </div>
      ) : (
        <div className="mt-6 grid gap-6 md:grid-cols-[1fr_320px]">
          <div className="space-y-3">
            {items.map((l) => (
              <div key={`${l.productSlug}::${l.sizeLabel}`} className="flex gap-3 rounded-2xl glass p-3">
                <img src={l.image} alt={l.name} loading="lazy" className="h-20 w-20 flex-shrink-0 rounded-xl object-cover" />
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{l.brand}</div>
                  <Link to="/product/$slug" params={{ slug: l.productSlug }} className="line-clamp-2 text-sm font-semibold hover:text-primary">
                    {l.name}
                  </Link>
                  <div className="mt-1 text-[11px] text-muted-foreground">{l.sizeLabel}</div>
                  <div className="mt-1 flex items-baseline gap-2">
                    <span className="text-sm font-bold text-primary">₹{l.unitPrice}</span>
                    {l.oldPrice > l.unitPrice && <span className="text-xs text-muted-foreground line-through">₹{l.oldPrice}</span>}
                    {l.oldPrice > l.unitPrice && (
                      <span className="text-[10px] font-bold text-emerald-600">Save ₹{(l.oldPrice - l.unitPrice) * l.qty}</span>
                    )}
                  </div>
                </div>
                <div className="flex flex-col items-end justify-between">
                  <button onClick={() => remove(l.productSlug, l.sizeLabel)} aria-label="Remove" className="text-muted-foreground hover:text-destructive">
                    <Trash2 size={16} />
                  </button>
                  <div className="inline-flex items-center rounded-full glass">
                    <button onClick={() => setQty(l.productSlug, l.sizeLabel, l.qty - 1)} className="grid h-8 w-8 place-items-center"><Minus size={14} /></button>
                    <span className="w-6 text-center text-sm font-bold">{l.qty}</span>
                    <button onClick={() => setQty(l.productSlug, l.sizeLabel, l.qty + 1)} className="grid h-8 w-8 place-items-center"><Plus size={14} /></button>
                  </div>
                </div>
              </div>
            ))}
            <button onClick={clear} className="text-xs text-muted-foreground hover:text-destructive">Clear cart</button>
          </div>

          <aside className="h-fit rounded-2xl glass p-4">
            <h2 className="text-sm font-bold uppercase tracking-wider">Order summary</h2>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Items ({count})</span>
                <span className="line-through">₹{subtotalOld}</span>
              </div>
              <div className="flex justify-between font-semibold text-emerald-600">
                <span>You save</span>
                <span>– ₹{savings}</span>
              </div>
              <div className="flex justify-between border-t border-border/40 pt-2 text-base font-bold">
                <span>Total</span>
                <span className="text-primary">₹{subtotalNow}</span>
              </div>
              {savings > 0 && (
                <div className="rounded-xl bg-primary/10 px-3 py-2 text-center text-xs font-semibold text-primary">
                  🎉 You're saving ₹{savings} ({Math.round((savings / subtotalOld) * 100)}% off)
                </div>
              )}
            </div>
            <a
              href={whatsappOrderLink(orderText)}
              target="_blank"
              rel="noreferrer"
              className="mt-4 flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground press"
            >
              <MessageCircle size={16} /> Order all on WhatsApp
            </a>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">We'll confirm stock & shipping over WhatsApp.</p>
          </aside>
        </div>
      )}
    </div>
  );
}
