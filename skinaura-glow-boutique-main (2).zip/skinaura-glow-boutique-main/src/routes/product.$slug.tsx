import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Star, MessageCircle, ShoppingBag, Upload, X } from "lucide-react";
import { productBySlug, imgOf, priceOf, whatsappOrderLink } from "@/lib/skinaura-utils";
import { isProductOOS } from "@/data/skinaura";
import { useCart } from "@/lib/cart-context";
import { useAuth } from "@/lib/auth-context";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/product/$slug")({
  head: ({ params }) => {
    const p = productBySlug[params.slug];
    return {
      meta: [
        { title: p ? `${p.name} — Skinaura` : "Product — Skinaura" },
        { name: "description", content: p?.description?.slice(0, 160) ?? "Skinaura product" },
        { property: "og:title", content: p?.name ?? "Skinaura product" },
        { property: "og:image", content: p?.images?.[0] ?? "" },
      ],
    };
  },
  component: ProductPage,
});

type Review = {
  id: string;
  user_id: string;
  product_slug: string;
  rating: number;
  body: string | null;
  image_url: string | null;
  created_at: string;
  display_name?: string | null;
};

function ProductPage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const p = productBySlug[slug];
  if (!p) throw notFound();

  const [sizeIdx, setSizeIdx] = useState(0);
  const [imgIdx, setImgIdx] = useState(0);
  const { add } = useCart();
  const { user } = useAuth();
  const { base, now, disc, sizeLabel } = useMemo(() => priceOf(p, sizeIdx), [p, sizeIdx]);
  const oos = isProductOOS(p.brand, p);

  const orderUrl = whatsappOrderLink(
    `Hi! I'd like to order:\n• ${p.brand} — ${p.name}\n• Size: ${sizeLabel}\n• Price: ₹${now}\nLink: ${typeof window !== "undefined" ? window.location.href : ""}`
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <button onClick={() => history.back()} className="inline-flex items-center gap-1 text-sm font-semibold text-primary press">
        <ArrowLeft size={16} /> Back
      </button>

      <div className="mt-4 grid gap-6 md:grid-cols-2">
        {/* Gallery */}
        <div>
          <div className="aspect-square overflow-hidden rounded-3xl glass">
            <img src={imgOf(p, imgIdx)} alt={p.name} className="h-full w-full object-cover" />
          </div>
          {p.images && p.images.length > 1 && (
            <div className="mt-3 flex gap-2 overflow-x-auto no-scrollbar">
              {p.images.map((src, i) => (
                <button
                  key={i}
                  onClick={() => setImgIdx(i)}
                  className={`h-16 w-16 flex-shrink-0 overflow-hidden rounded-xl border-2 ${i === imgIdx ? "border-primary" : "border-transparent"}`}
                >
                  <img src={src} alt="" className="h-full w-full object-cover" loading="lazy" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Details */}
        <div>
          <Link to="/brand/$slug" params={{ slug: p.brand.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") }} className="text-xs uppercase tracking-wider text-primary font-semibold">
            {p.brand}
          </Link>
          <h1 className="mt-1 bold-tight text-2xl md:text-3xl">{p.name}</h1>

          <div className="mt-3 flex items-baseline gap-3">
            <span className="text-3xl font-bold text-primary">₹{now}</span>
            {disc > 0 && (
              <>
                <span className="text-lg text-muted-foreground line-through">₹{base}</span>
                <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-bold text-primary">{disc}% OFF</span>
              </>
            )}
          </div>

          {/* Sizes */}
          {p.sizes.length > 1 && (
            <div className="mt-5">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Size</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {p.sizes.map((s, i) => (
                  <button
                    key={s.label}
                    onClick={() => setSizeIdx(i)}
                    className={`rounded-full border px-4 py-2 text-sm font-semibold press ${i === sizeIdx ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white"}`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="mt-6 grid grid-cols-2 gap-2">
            <button
              disabled={oos}
              onClick={async () => {
                await add({ productSlug: p.slug, brand: p.brand, name: p.name, image: imgOf(p), sizeLabel, unitPrice: now, oldPrice: base, qty: 1 });
                toast.success("Added to cart");
              }}
              className="flex items-center justify-center gap-2 rounded-full glass px-5 py-3 text-sm font-semibold press disabled:opacity-50"
            >
              <ShoppingBag size={16} /> Add to cart
            </button>
            <a
              href={oos ? undefined : orderUrl}
              target="_blank"
              rel="noreferrer"
              aria-disabled={oos}
              className={`flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground press ${oos ? "pointer-events-none opacity-50" : ""}`}
            >
              <MessageCircle size={16} /> Order on WhatsApp
            </a>
          </div>
          {oos && <p className="mt-2 text-xs text-destructive">This item is currently out of stock.</p>}

          {/* Description */}
          {p.description && (
            <div className="mt-6">
              <h2 className="text-sm font-bold uppercase tracking-wider">About this product</h2>
              <p className="mt-2 text-sm leading-relaxed text-foreground/80">{p.description.replace(/ssdsatacipher\d+\s?/g, "")}</p>
            </div>
          )}
          {p.ingredients && (
            <div className="mt-4">
              <h2 className="text-sm font-bold uppercase tracking-wider">Key ingredients</h2>
              <p className="mt-1 text-sm text-foreground/80">{p.ingredients}</p>
            </div>
          )}
          {p.howToUse && (
            <div className="mt-4">
              <h2 className="text-sm font-bold uppercase tracking-wider">How to use</h2>
              <p className="mt-1 text-sm text-foreground/80 whitespace-pre-line">{p.howToUse}</p>
            </div>
          )}
          {p.benefits && p.benefits.length > 0 && (
            <div className="mt-4">
              <h2 className="text-sm font-bold uppercase tracking-wider">Benefits</h2>
              <ul className="mt-2 grid grid-cols-1 gap-1 text-sm text-foreground/80 sm:grid-cols-2">
                {p.benefits.map((b) => (<li key={b}>• {b}</li>))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <Reviews slug={slug} loggedIn={!!user} onLogin={() => navigate({ to: "/auth" })} />
    </div>
  );
}

function Reviews({ slug, loggedIn, onLogin }: { slug: string; loggedIn: boolean; onLogin: () => void }) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(5);
  const [body, setBody] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function enrich(rows: any[]) {
      const ids = Array.from(new Set(rows.map((r) => r.user_id)));
      if (!ids.length) return rows;
      const { data: profs } = await supabase.from("profiles").select("id, display_name").in("id", ids);
      const m = new Map((profs ?? []).map((p: any) => [p.id, p.display_name]));
      return rows.map((r) => ({ ...r, display_name: m.get(r.user_id) ?? "Anonymous" }));
    }
    (async () => {
      setLoading(true);
      const { data } = await supabase.from("reviews").select("*").eq("product_slug", slug).order("created_at", { ascending: false });
      if (cancelled) return;
      setReviews(await enrich(data ?? []));
      setLoading(false);
    })();
    const ch = supabase
      .channel(`reviews:${slug}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "reviews", filter: `product_slug=eq.${slug}` }, async (payload) => {
        const enriched = await enrich([payload.new as any]);
        setReviews((prev) => [enriched[0], ...prev]);
      })
      .subscribe();
    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, [slug]);

  async function submit() {
    if (!loggedIn) return onLogin();
    setSubmitting(true);
    try {
      const { data: session } = await supabase.auth.getUser();
      const uid = session.user?.id;
      if (!uid) throw new Error("Not logged in");
      let imageUrl: string | null = null;
      if (file) {
        const path = `${uid}/${slug}-${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
        const { error: uErr } = await supabase.storage.from("review-photos").upload(path, file, { upsert: false });
        if (uErr) throw uErr;
        const { data: signed } = await supabase.storage.from("review-photos").createSignedUrl(path, 60 * 60 * 24 * 365);
        imageUrl = signed?.signedUrl ?? null;
      }
      const { error } = await supabase.from("reviews").insert({
        user_id: uid, product_slug: slug, rating, body: body.trim() || null, image_url: imageUrl,
      });
      if (error) throw error;
      setBody(""); setFile(null); setRating(5);
      toast.success("Thanks for your review!");
    } catch (e: any) {
      toast.error(e.message || "Could not post review");
    } finally {
      setSubmitting(false);
    }
  }

  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

  return (
    <section className="mt-12">
      <h2 className="bold-tight text-2xl">Reviews <span className="display text-gradient-pink">& glow stories</span></h2>
      <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
        <Stars value={avg} /> <span>{avg.toFixed(1)} · {reviews.length} review{reviews.length === 1 ? "" : "s"}</span>
      </div>

      <div className="mt-5 rounded-2xl glass p-4">
        {!loggedIn ? (
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Sign in to share your experience and post photos.</p>
            <button onClick={onLogin} className="mt-3 rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground press">Sign in / Sign up</button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold">Your rating:</span>
              {[1,2,3,4,5].map((n) => (
                <button key={n} onClick={() => setRating(n)} aria-label={`${n} stars`}>
                  <Star size={22} className={n <= rating ? "fill-primary text-primary" : "text-muted-foreground"} />
                </button>
              ))}
            </div>
            <textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Tell others about your experience…" rows={3} className="w-full rounded-xl border border-border bg-white/80 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40" />
            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-full glass px-3 py-2 text-sm font-semibold press">
                <Upload size={14} /> {file ? "Change photo" : "Add photo"}
                <input type="file" accept="image/*" hidden onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
              </label>
              {file && (
                <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                  {file.name}
                  <button onClick={() => setFile(null)}><X size={12} /></button>
                </span>
              )}
              <button onClick={submit} disabled={submitting} className="ml-auto rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground press disabled:opacity-60">
                {submitting ? "Posting…" : "Post review"}
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="mt-5 space-y-3">
        {loading && <p className="text-sm text-muted-foreground">Loading reviews…</p>}
        {!loading && reviews.length === 0 && <p className="text-sm text-muted-foreground">No reviews yet — be the first!</p>}
        {reviews.map((r) => (
          <div key={r.id} className="rounded-2xl glass p-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold">{r.display_name || "Anonymous"}</div>
                <Stars value={r.rating} />
              </div>
              <span className="text-[11px] text-muted-foreground">{new Date(r.created_at).toLocaleDateString()}</span>
            </div>
            {r.body && <p className="mt-2 text-sm text-foreground/85">{r.body}</p>}
            {r.image_url && <img src={r.image_url} alt="" loading="lazy" className="mt-3 max-h-72 rounded-xl object-cover" />}
          </div>
        ))}
      </div>
    </section>
  );
}

function Stars({ value }: { value: number }) {
  return (
    <span className="inline-flex">
      {[1,2,3,4,5].map((n) => (
        <Star key={n} size={14} className={n <= Math.round(value) ? "fill-primary text-primary" : "text-muted-foreground"} />
      ))}
    </span>
  );
}
