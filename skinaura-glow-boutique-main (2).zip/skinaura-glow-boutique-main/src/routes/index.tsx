import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { brands, allProducts, CATEGORIES, slugify } from "@/lib/skinaura-utils";
import { ProductCard } from "@/components/skinaura/ProductCard";
import heroFestivePlix from "@/assets/hero-festive-plix.png.asset.json";
import heroEssentialsFacewash from "@/assets/hero-essentials-facewash.png.asset.json";
import heroGlassGlowingFestival from "@/assets/hero-glass-glowing-festival.png.asset.json";
import promoMars from "@/assets/promo-mars.png.asset.json";
import promoDotkey from "@/assets/promo-dotkey.png.asset.json";
import promoPlix from "@/assets/promo-plix.png.asset.json";
import promoTeen from "@/assets/promo-teenteen.png.asset.json";
import bannerColorLife from "@/assets/banner-colorlife.png.asset.json";

const HERO_SLIDES = [
  {
    img: heroFestivePlix,
    alt: "Skinaura Festives — up to 35% off on Plix",
    position: "object-[58%_center] sm:object-center",
  },
  {
    img: heroEssentialsFacewash,
    alt: "Skinaura Essentials Nykaa facewash collection",
    position: "object-[62%_center] sm:object-center",
  },
  {
    img: heroGlassGlowingFestival,
    alt: "Skinaura Glass Glowing Festival banner",
    position: "object-[68%_center] sm:object-center",
  },
] as const;

const PROMOS = [
  { brand: "Mars", slug: "mars", img: promoMars, title: "Mars cosmetics", sub: "Mars cosmetics on Skinaura" },
  { brand: "Dot & Key", slug: "dot-and-key", img: promoDotkey, title: "Dot & Key Days!", sub: "Dot & Key products with huge discounts" },
  { brand: "Plix", slug: "plix", img: promoPlix, title: "Plix World", sub: "Get Plix products at affordable price" },
  { brand: "Teen-Teen", slug: "teen-teen", img: promoTeen, title: "Teen - Teen", sub: "UPTO 50% OFF" },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Skinaura — Glow, Reimagined." },
      { name: "description", content: "Premium makeup & skincare from Plix, Mars, Derma-Co, Mama Earth and more — up to 40% off." },
      { property: "og:title", content: "Skinaura — Glow, Reimagined." },
      { property: "og:description", content: "Premium makeup & skincare with up to 40% off." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div>
      <section>
        <div className="relative w-full overflow-hidden">
          <div className="relative aspect-[3/2] w-full">
            {HERO_SLIDES.map((slide, index) => (
              <img
                key={slide.alt}
                src={slide.img.url}
                alt={slide.alt}
                loading={index === 0 ? "eager" : "lazy"}
                fetchPriority={index === 0 ? "high" : undefined}
                className={`hero-slide hero-slide-${index + 1} absolute inset-0 h-full w-full object-contain bg-muted`}
              />
            ))}
            <div className="absolute bottom-3 left-1/2 z-10 flex -translate-x-1/2 gap-2 rounded-full bg-background/70 px-3 py-1.5 shadow-petal">
              <span className="hero-dot hero-dot-1" />
              <span className="hero-dot hero-dot-2" />
              <span className="hero-dot hero-dot-3" />
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-3 sm:px-4 md:px-6">
        <section className="mt-8 sm:mt-10">
          <div className="mb-4 flex items-end justify-between">
            <h2 className="bold-tight text-2xl md:text-3xl">
              In the <span className="display text-gradient-pink">spotlight</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {PROMOS.map((promo) => (
              <div key={promo.slug} className="relative glass card-hover overflow-hidden">
                <img src={promo.img.url} alt={promo.title} loading="lazy" className="h-48 w-full object-cover sm:h-56" />
                <div className="p-4">
                  <div className="text-lg font-bold">{promo.title}</div>
                  <div className="mb-3 text-sm text-muted-foreground">{promo.sub}</div>
                  <Link
                    to="/brand/$slug"
                    params={{ slug: promo.slug }}
                    className="inline-flex items-center gap-1 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
                  >
                    Shop Now <ArrowRight size={14} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-8 sm:mt-10">
          <div className="mb-4 flex items-end justify-between gap-3">
            <h2 className="bold-tight text-2xl md:text-3xl">
              Loved <span className="display text-gradient-pink">brands</span>
            </h2>
            <span className="text-right text-[11px] text-muted-foreground sm:text-xs">Tap a brand to see all its products</span>
          </div>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6">
            {brands.map((b) => (
              <Link
                key={b.name}
                to="/brand/$slug"
                params={{ slug: slugify(b.name) }}
                className="group block rounded-2xl glass p-3 text-center card-hover"
              >
                <div className="mx-auto grid h-16 w-16 place-items-center overflow-hidden rounded-full bg-white">
                  <img src={b.logo} alt={b.name} loading="lazy" className="h-full w-full object-contain" />
                </div>
                <div className="mt-2 text-sm font-semibold">{b.name}</div>
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{b.tag}</div>
              </Link>
            ))}
          </div>
        </section>

        <section className="mt-6 sm:mt-8">
          <Link to="/brand/$slug" params={{ slug: "teen-teen" }} className="block shadow-md card-hover">
            <img
              src={bannerColorLife.url}
              alt="Super Stay Color Life — Non-transfer Lipstick"
              loading="lazy"
              className="h-auto w-full"
            />
          </Link>
        </section>

        <section className="mt-10 sm:mt-12">
          <div className="mb-4 flex items-end justify-between">
            <h2 className="bold-tight text-2xl md:text-3xl">
              Shop by <span className="display text-gradient-pink">category</span>
            </h2>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {CATEGORIES.map((c) => (
              <Link
                key={c.slug}
                to="/category/$slug"
                params={{ slug: c.slug }}
                className="group relative aspect-[4/5] overflow-hidden rounded-[2rem] glass card-hover"
              >
                <img src={c.img} alt={c.name} loading="lazy" className="absolute inset-0 h-full w-full object-cover object-center" />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/45 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4 text-primary-foreground sm:p-5">
                  <div className="text-2xl font-bold sm:text-xl">{c.name}</div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="mt-10 sm:mt-12">
          <div className="mb-4 flex items-end justify-between gap-3">
            <h2 className="bold-tight text-2xl md:text-3xl">
              Shop <span className="display text-gradient-pink">favourites</span>
            </h2>
            <Link to="/search" className="inline-flex items-center gap-1 text-xs font-semibold text-primary">
              See search <ArrowRight size={12} />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {allProducts.map((p) => (
              <ProductCard key={p.slug} p={p} />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
