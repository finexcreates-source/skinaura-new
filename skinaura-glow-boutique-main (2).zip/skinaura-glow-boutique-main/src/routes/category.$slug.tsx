import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { CATEGORIES, SUBCATEGORIES, productsByCategory, productsBySubcategory } from "@/lib/skinaura-utils";
import { ProductCard } from "@/components/skinaura/ProductCard";
import { z } from "zod";

const search = z.object({ sub: z.string().optional() });

export const Route = createFileRoute("/category/$slug")({
  validateSearch: search,
  head: ({ params }) => ({
    meta: [
      { title: `${params.slug} — Skinaura` },
      { name: "description", content: `Shop all ${params.slug} products on Skinaura.` },
    ],
  }),
  component: CategoryPage,
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const { sub } = Route.useSearch();
  const navigate = useNavigate();
  const cat = CATEGORIES.find((c) => c.slug === slug);
  if (!cat) throw notFound();
  const subs = SUBCATEGORIES[slug] ?? [];
  const activeSub = sub ? subs.find(s => s.slug === sub) : null;

  const products = activeSub
    ? productsBySubcategory(slug, activeSub.slug)
    : productsByCategory(slug);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <button
        onClick={() => activeSub ? navigate({ to: "/category/$slug", params: { slug }, search: {} }) : navigate({ to: "/" })}
        className="inline-flex items-center gap-1 text-sm font-semibold text-primary press"
      >
        <ArrowLeft size={16} /> Back
      </button>

      <div className="mt-4 flex items-center gap-4 rounded-2xl glass p-4">
        <img
          src={activeSub ? activeSub.img : cat.img}
          alt={activeSub ? activeSub.name : cat.name}
          loading="lazy"
          className="h-14 w-14 rounded-xl object-cover"
        />
        <div>
          <h1 className="bold-tight text-2xl md:text-3xl">
            {activeSub ? activeSub.name : cat.name}{" "}
            <span className="display text-gradient-pink">{activeSub ? "collection" : ""}</span>
          </h1>
          <p className="text-xs uppercase tracking-wider text-muted-foreground">
            {activeSub ? `${products.length} products` : `${subs.length} categories`}
          </p>
        </div>
      </div>

      {/* Show subcategories if no sub selected and subs exist */}
      {!activeSub && subs.length > 0 && (
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {subs.map((s) => (
            <Link
              key={s.slug}
              to="/category/$slug"
              params={{ slug }}
              search={{ sub: s.slug }}
              className="group relative aspect-square overflow-hidden rounded-2xl glass-pink card-hover"
            >
              <img src={s.img} alt={s.name} loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-3 text-white text-center font-bold text-sm md:text-base">
                {s.name}
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* Product grid */}
      {(activeSub || subs.length === 0) && (
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {products.length === 0 ? (
            <p className="col-span-full text-center text-sm text-muted-foreground py-12">No products found in this category yet.</p>
          ) : products.map((p) => (<ProductCard key={p.slug} p={p} />))}
        </div>
      )}
    </div>
  );
}
