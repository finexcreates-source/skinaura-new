import { brands, otherProducts, productData, getDiscount, getNewPrice, isProductOOS, PLACEHOLDER, type Product } from "@/data/skinaura";
import catSkincare from "@/assets/cat-skincare-real.png.asset.json";
import catHaircare from "@/assets/cat-haircare-real.png.asset.json";
import catMakeup from "@/assets/cat-makeup-real.png.asset.json";
import subFacewash from "@/assets/sub-facewash.jpg";
import subMoisturizer from "@/assets/sub-moisturizer.jpg";
import subSerums from "@/assets/sub-serums.jpg";
import subSunscreens from "@/assets/sub-sunscreens.jpg";
import subFacialKits from "@/assets/sub-facial-kits.jpg";
import subShampoos from "@/assets/sub-shampoos.jpg";
import subConditioners from "@/assets/sub-conditioners.jpg";
import subHairMasks from "@/assets/sub-hair-masks.jpg";
import subHairOils from "@/assets/sub-hair-oils.jpg";
import subHairSerums from "@/assets/sub-hair-serums.jpg";
import subHairSprays from "@/assets/sub-hair-sprays.jpg";
import subBaseSetting from "@/assets/sub-base-setting.jpg";
import subBase from "@/assets/sub-base.jpg";
import subEyes from "@/assets/sub-eyes.jpg";
import subHighlight from "@/assets/sub-highlight.jpg";
import subLipstick from "@/assets/sub-lipstick.jpg";
import subLipLiner from "@/assets/sub-lip-liner.jpg";

export const WHATSAPP_NUMBER = "917317495206";
export const INSTAGRAM_URL = "https://instagram.com/myskinaura.in";
export const CONTACT_EMAIL = "skinaura.in@gmail.com";
export const CONTACT_PHONE = "+91 7317495206";

export type FlatProduct = Product & { brand: string; slug: string; category: string };

export function slugify(s: string): string {
  return s.toLowerCase().replace(/&/g, "and").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

const CATEGORY_BY_CODE: Record<string, string> = {
  "99": "skincare",
  "100": "skincare",
  "101": "skincare",
  "102": "skincare",
  "103": "skincare",
  "104": "makeup",
  "105": "makeup",
  "106": "makeup",
  "107": "makeup",
};

export const CATEGORIES = [
  { slug: "skincare", name: "Skincare", img: catSkincare.url },
  { slug: "haircare", name: "Haircare", img: catHaircare.url },
  { slug: "makeup", name: "Makeup", img: catMakeup.url },
];

export type SubMatcher = (p: Product) => boolean;
export type SubCat = { slug: string; name: string; img: string; match: SubMatcher };

export const SUBCATEGORIES: Record<string, SubCat[]> = {
  skincare: [
    { slug: "facewash", name: "Facewash", img: subFacewash, match: (p) => /ssdsatacipher100/i.test(p.description) },
    { slug: "moisturizer", name: "Moisturizer", img: subMoisturizer, match: (p) => /ssdsatacipher101/i.test(p.description) },
    { slug: "serums", name: "Serums", img: subSerums, match: (p) => /ssdsatacipher103/i.test(p.description) },
    { slug: "sunscreens", name: "Sunscreens", img: subSunscreens, match: (p) => /ssdsatacipher99/i.test(p.description) },
    { slug: "facial-kits", name: "Facial Kits", img: subFacialKits, match: (p) => /ssdsatacipher102/i.test(p.description) },
  ],
  haircare: [
    { slug: "shampoos", name: "Shampoos", img: subShampoos, match: (p) => /shampoo/i.test(p.name) },
    { slug: "conditioners", name: "Conditioners", img: subConditioners, match: (p) => /conditioner/i.test(p.name) },
    { slug: "hair-masks", name: "Hair Masks", img: subHairMasks, match: (p) => /hair.?mask|treatment.*mask|mask.*treatment/i.test(p.name) },
    { slug: "hair-oils", name: "Hair Oils", img: subHairOils, match: (p) => /hair.?oil|oil.*hair|onion.*oil/i.test(p.name) && !/face/i.test(p.name) },
    { slug: "hair-serums", name: "Hair Serums", img: subHairSerums, match: (p) => /hair.?(growth.)?serum|serum.*hair/i.test(p.name) },
    { slug: "hair-sprays", name: "Hair Sprays", img: subHairSprays, match: (p) => /hair.*spray|spray.*hair|growth.*spray|spray.*growth/i.test(p.name) },
  ],
  makeup: [
    { slug: "base-setting", name: "Base Setting", img: subBaseSetting, match: (p) => /ssdsatacipher106/i.test(p.description) },
    { slug: "base", name: "Base", img: subBase, match: (p) => /ssdsatacipher105/i.test(p.description) },
    { slug: "eyes", name: "Eyes", img: subEyes, match: (p) => /ssdsatacipher104/i.test(p.description) },
    { slug: "highlight", name: "Highlight", img: subHighlight, match: (p) => /ssdsatacipher107/i.test(p.description) },
    { slug: "lipstick", name: "Lipstick", img: subLipstick, match: (p) => /lipstick|lip.*stick/i.test(p.name) && !/liner/i.test(p.name) },
    { slug: "lip-liner", name: "Lip Liner", img: subLipLiner, match: (p) => /lip.?liner|lipliner/i.test(p.name) },
  ],
};

function categoryOf(p: Product, _brand: string): string {
  const m = (p.description || "").match(/ssdsatacipher(\d+)/);
  if (m && CATEGORY_BY_CODE[m[1]]) return CATEGORY_BY_CODE[m[1]];
  if (/shampoo|conditioner|hair.?(mask|oil|serum|spray)|onion|rosemary/i.test(p.name)) return "haircare";
  if (/lipstick|lip.?liner|kajal|mascara|eyeshadow|eyeliner|compact|foundation|concealer|highlighter|blush|primer/i.test(p.name)) return "makeup";
  return "skincare";
}

function buildCatalog(): FlatProduct[] {
  const all: FlatProduct[] = [];
  const seen = new Set<string>();
  const make = (brand: string, p: Product): FlatProduct => {
    const base = slugify(`${brand}-${p.name}`).slice(0, 80);
    let slug = base;
    let i = 2;
    while (seen.has(slug)) slug = `${base}-${i++}`;
    seen.add(slug);
    return { ...p, brand, slug, category: categoryOf(p, brand) };
  };
  for (const [brand, list] of Object.entries(productData)) for (const p of list) all.push(make(brand, p));
  for (const p of otherProducts) all.push(make("Other", p));
  return all;
}

export const allProducts: FlatProduct[] = buildCatalog();
export const productBySlug: Record<string, FlatProduct> = Object.fromEntries(allProducts.map((p) => [p.slug, p]));

export function productsByBrand(brand: string): FlatProduct[] {
  return allProducts.filter((p) => p.brand.toLowerCase() === brand.toLowerCase());
}
export function productsByCategory(slug: string): FlatProduct[] {
  return allProducts.filter((p) => p.category === slug);
}
export function productsBySubcategory(catSlug: string, subSlug: string): FlatProduct[] {
  const sub = (SUBCATEGORIES[catSlug] || []).find((s) => s.slug === subSlug);
  if (!sub) return [];
  return allProducts.filter(sub.match);
}
export function brandBySlug(s: string) {
  return brands.find((b) => slugify(b.name) === s);
}

export function searchProducts(q: string): FlatProduct[] {
  const t = q.trim().toLowerCase();
  if (!t) return [];
  return allProducts.filter(
    (p) => p.name.toLowerCase().includes(t) || p.brand.toLowerCase().includes(t) || p.category.includes(t),
  );
}

export function priceOf(p: Product, sizeIdx = 0) {
  const s = p.sizes[sizeIdx] ?? p.sizes[0];
  const base = Math.round(p.oldPrice * (s?.mult ?? 1));
  return { base, now: getNewPrice(p, base), disc: getDiscount(p), sizeLabel: s?.label ?? "" };
}
export function imgOf(p: Product, i = 0) {
  return p.images?.[i] || PLACEHOLDER;
}

export function whatsappOrderLink(text: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}

export { brands, getDiscount, getNewPrice, isProductOOS, PLACEHOLDER };
