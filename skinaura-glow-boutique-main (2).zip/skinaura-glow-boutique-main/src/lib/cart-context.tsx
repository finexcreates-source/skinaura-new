import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./auth-context";

export type CartLine = {
  productSlug: string;
  brand: string;
  name: string;
  image: string;
  sizeLabel: string;
  unitPrice: number;   // discounted
  oldPrice: number;    // before discount
  qty: number;
};

type CartCtx = {
  items: CartLine[];
  add: (line: Omit<CartLine, "qty"> & { qty?: number }) => Promise<void>;
  remove: (slug: string, sizeLabel: string) => Promise<void>;
  setQty: (slug: string, sizeLabel: string, qty: number) => Promise<void>;
  clear: () => Promise<void>;
  count: number;
  subtotalOld: number;
  subtotalNow: number;
  savings: number;
};

const Ctx = createContext<CartCtx | null>(null);
const LS_KEY = "skinaura.cart.v1";

function keyOf(slug: string, size: string) { return `${slug}::${size}`; }
function loadLocal(): CartLine[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(LS_KEY) || "[]"); } catch { return []; }
}
function saveLocal(items: CartLine[]) {
  if (typeof window !== "undefined") localStorage.setItem(LS_KEY, JSON.stringify(items));
}

export function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [items, setItems] = useState<CartLine[]>(() => loadLocal());

  // Load from cloud when logged in; merge local guest cart up
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const guest = loadLocal();
      if (guest.length) {
        await supabase.from("cart_items").upsert(
          guest.map((l) => ({
            user_id: user.id,
            product_slug: l.productSlug,
            brand: l.brand,
            name: l.name,
            image: l.image,
            size_label: l.sizeLabel,
            unit_price: l.unitPrice,
            old_price: l.oldPrice,
            qty: l.qty,
          })),
          { onConflict: "user_id,product_slug,size_label" }
        );
        localStorage.removeItem(LS_KEY);
      }
      const { data } = await supabase.from("cart_items").select("*").eq("user_id", user.id);
      if (cancelled) return;
      setItems((data ?? []).map((r: any) => ({
        productSlug: r.product_slug, brand: r.brand, name: r.name, image: r.image,
        sizeLabel: r.size_label, unitPrice: r.unit_price, oldPrice: r.old_price, qty: r.qty,
      })));
    })();
    return () => { cancelled = true; };
  }, [user]);

  // Persist local cart for guests
  useEffect(() => { if (!user) saveLocal(items); }, [items, user]);

  const add = useCallback(async (line: Omit<CartLine, "qty"> & { qty?: number }) => {
    const qty = line.qty ?? 1;
    setItems((prev) => {
      const idx = prev.findIndex((p) => keyOf(p.productSlug, p.sizeLabel) === keyOf(line.productSlug, line.sizeLabel));
      if (idx >= 0) {
        const next = [...prev]; next[idx] = { ...next[idx], qty: next[idx].qty + qty }; return next;
      }
      return [...prev, { ...line, qty }];
    });
    if (user) {
      await supabase.from("cart_items").upsert({
        user_id: user.id, product_slug: line.productSlug, brand: line.brand, name: line.name,
        image: line.image, size_label: line.sizeLabel, unit_price: line.unitPrice, old_price: line.oldPrice, qty,
      }, { onConflict: "user_id,product_slug,size_label", ignoreDuplicates: false });
    }
  }, [user]);

  const remove = useCallback(async (slug: string, sizeLabel: string) => {
    setItems((prev) => prev.filter((p) => !(p.productSlug === slug && p.sizeLabel === sizeLabel)));
    if (user) await supabase.from("cart_items").delete().match({ user_id: user.id, product_slug: slug, size_label: sizeLabel });
  }, [user]);

  const setQty = useCallback(async (slug: string, sizeLabel: string, qty: number) => {
    if (qty <= 0) return remove(slug, sizeLabel);
    setItems((prev) => prev.map((p) => p.productSlug === slug && p.sizeLabel === sizeLabel ? { ...p, qty } : p));
    if (user) await supabase.from("cart_items").update({ qty }).match({ user_id: user.id, product_slug: slug, size_label: sizeLabel });
  }, [user, remove]);

  const clear = useCallback(async () => {
    setItems([]);
    if (user) await supabase.from("cart_items").delete().eq("user_id", user.id);
    else saveLocal([]);
  }, [user]);

  const totals = useMemo(() => {
    const count = items.reduce((s, l) => s + l.qty, 0);
    const subtotalOld = items.reduce((s, l) => s + l.oldPrice * l.qty, 0);
    const subtotalNow = items.reduce((s, l) => s + l.unitPrice * l.qty, 0);
    return { count, subtotalOld, subtotalNow, savings: subtotalOld - subtotalNow };
  }, [items]);

  return <Ctx.Provider value={{ items, add, remove, setQty, clear, ...totals }}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}
