Here's the plan for everything you asked. It's a lot, so I'm grouping it. I'll need to enable **Lovable Cloud** for login, cart sync, and reviews with photo upload.

## 1. Branding
- Upload your lotus logo + use as favicon (apple-touch-icon, OG image).
- Replace the current "S" mark in the header and hero with the lotus.

## 2. Performance (smoothness on PC + mobile)
- Remove heavy backdrop-blur + animated gradient blobs from the body background (the main lag cause).
- Replace marquee/float animations with `will-change` + GPU-only transforms; pause off-screen.
- Lazy-load product images (`loading="lazy"`, `decoding="async"`) and split product data into chunks.
- Code-split routes (product, brand, category, search, cart, auth pages).

## 3. New routes (no more popups, no more navbar dropdown)
```
/                  → home (hero, brands, categories, featured)
/category/$slug    → Skincare / Haircare / Makeup / Fragrance / Bodycare / etc.
/brand/$slug       → e.g. /brand/plix → "Plix Products" with back button
/product/$slug     → full product page with size selector + order button
/search            → dedicated search page (input + grid, no navbar bar)
/cart              → cart with discount breakdown
/auth              → login / signup
/account/orders    → (optional later)
```
Each gets its own `head()` meta for SEO.

## 4. Shop by Category (re-added between Brands and Shop)
- Parse your `ssdsatacipher` codes from product descriptions:
  - `99` = Suncare, `100` = Face Wash/Cleanser, `101` = Serum/Body, `103` = Hair/Skin treatment, `106` = Makeup, etc. (I'll map them to: **Skincare, Haircare, Makeup, Fragrance, Bodycare, Suncare** based on the old site).
- Category cards link to `/category/$slug`.

## 5. Product page
- Size selector when product has multiple sizes (price updates).
- Single "Order on WhatsApp" button → opens `https://wa.me/917317495206?text=...` pre-filled with product name + selected size + price.
- "Add to cart" stays; cart-level WhatsApp order also available.

## 6. Cart with discount display
- Show **old price (struck-through)**, **new price**, per-item savings, **total saved**, and final total.
- "Order all on WhatsApp" button.
- Cart persists to Cloud when logged in; localStorage fallback when guest.

## 7. Auth (Lovable Cloud)
- Email + password sign up / sign in.
- `profiles` + `carts` + `reviews` tables with RLS.
- Login required to checkout and to post reviews.

## 8. Reviews
- On each product page: list of reviews + "Write a review" (requires login).
- Star rating, text, optional photo (uploaded to Cloud storage).
- Real-time: new reviews appear instantly via Supabase realtime.

## 9. Search page
- Dedicated `/search?q=` page, full grid results, filters by brand/category.
- Navbar search icon just links to `/search`.

---

### What I need from you before building
1. **Confirm enabling Lovable Cloud** (required for auth + cart sync + reviews/photos). Yes/no?
2. **Category mapping** — is this right?
   - 99 → Suncare · 100 → Cleansers · 101 → Serums & Body · 103 → Haircare · 106 → Makeup · 107 → Fragrance
   - Or should I just use the 3 from the old site: **Skincare / Haircare / Makeup**?

Reply with **"yes, go"** + your category preference and I'll build it all.