
CREATE POLICY "review_photos_read_all" ON storage.objects FOR SELECT
  USING (bucket_id = 'review-photos');
CREATE POLICY "review_photos_user_insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'review-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "review_photos_user_update" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'review-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "review_photos_user_delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'review-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
